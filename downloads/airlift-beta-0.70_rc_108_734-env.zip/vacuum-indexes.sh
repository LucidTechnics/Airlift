$AIRLIFT_APP_ENGINE_HOME/bin/appcfg.sh vacuum_indexes war
