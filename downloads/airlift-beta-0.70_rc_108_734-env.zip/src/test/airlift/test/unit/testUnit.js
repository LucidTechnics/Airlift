
exports['test test harness'] = function(_assert)
{
	_assert.ok(true, 'test harness not working');
};