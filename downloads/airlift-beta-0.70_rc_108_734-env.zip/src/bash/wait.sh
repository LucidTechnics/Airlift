#!/bin/bash

i=""
j="INFO: Successfully processed /Users/joshualee/work/AntTest/env/war/WEB-INF/backends.xml"
while [$i -ne $j]
do
sleep 1
//set i to something new
done